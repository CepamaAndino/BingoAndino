/**

 * BINGO ANDINO 2026 - Backend (Google Apps Script)

 * -------------------------------------------------

 * VERSIÓN CON MEJORAS DE SEGURIDAD

 *

 * CÓMO ACTUALIZAR (la URL /exec NO cambia):

 * 1. En el editor de Apps Script, reemplaza TODO el código por este archivo.

 * 2. CAMBIA ADMIN_PASSWORD (más abajo) por una clave larga tuya.

 * 3. Implementar > Administrar implementaciones > lápiz (editar)

 *    > Versión: "Nueva versión" > Implementar.

 *

 * COLUMNAS DE LA PLANILLA "Transacciones":

 * A:ID  B:Fecha  C:Comprador  D:Alumno  E:Curso  F:WhatsApp  G:Cantidad

 * H:CartonDesde  I:CartonHasta  J:Monto  K:Estado  L:FechaAprobacion

 * M:Email  N:Modo  O:Sets

 */



const SHEET_ID = '19hBEWOr2USFJsJAjQQXK2bDW_08pkgI2GFeSUx87dO0';

const SHEET_NAME = 'Transacciones';

const TOTAL_CARTONES = 3000;

const CARTONES_POR_SET = 6;

const ADMIN_PASSWORD = 'Cepamabingo2026'; // <-- CAMBIA ESTA CLAVE POR UNA LARGA Y DISTINTA

const MAIL_FROM_NAME = 'BINGO ANDINO 2026 - Colegio Andino Montessori';

const CEPAMA_NOTIFY_EMAIL = 'cepama.andino.montessori@gmail.com';



/* ---- Límites de seguridad ---- */

const MAX_SETS_POR_COMPRA = 10;        // máximo de sets en una sola compra online

const MAX_PENDIENTES_POR_WSP = 3;      // compras pendientes simultáneas por WhatsApp

const MAX_INTENTOS_ADMIN = 10;         // intentos fallidos de clave antes de bloquear

const BLOQUEO_SEGUNDOS = 600;          // 10 minutos de bloqueo



/**

 * PRECIOS

 * Modo "preventa":

 *   - 1 set (6 cartones)  = $9.000   ($1.500 c/u)

 *   - 2 sets (12 cartones, "pack familia") = $12.000 total

 *   - 3+ sets: se cobra el pack de 2 ($12.000) + cada set extra a $9.000

 * Modo "evento" (el mismo día del bingo):

 *   - cada set (6 cartones) = $12.000 ($2.000 c/u)

 */

function calcularPrecio(modo, sets) {

  const cartones = sets * CARTONES_POR_SET;

  if (modo === 'evento') {

    return { cartones: cartones, monto: sets * 12000 };

  }

  // preventa

  if (sets === 1) return { cartones: cartones, monto: 9000 };

  if (sets === 2) return { cartones: cartones, monto: 12000 };

  const monto = 12000 + (sets - 2) * 9000;

  return { cartones: cartones, monto: monto };

}



/* ============ SEGURIDAD: CLAVE DE ADMINISTRADOR ============ */

// Revisa la clave y bloquea temporalmente si hay demasiados intentos fallidos.

function checkAdmin(password) {

  const cache = CacheService.getScriptCache();

  const fails = parseInt(cache.get('ADMIN_FAILS') || '0', 10);

  if (fails >= MAX_INTENTOS_ADMIN) {

    throw new Error('Demasiados intentos fallidos. Espera 10 minutos e intenta de nuevo.');

  }

  if (password !== ADMIN_PASSWORD) {

    cache.put('ADMIN_FAILS', String(fails + 1), BLOQUEO_SEGUNDOS);

    throw new Error('Contraseña incorrecta');

  }

  cache.remove('ADMIN_FAILS');

}



function doPost(e) {

  try {

    const body = JSON.parse(e.postData.contents);

    const action = body.action;

    const payload = body.payload || {};

    let result;

    switch (action) {

      case 'checkStatus':

        result = checkStatus(payload.whatsapp);

        break;

      case 'submitPurchase':

        result = submitPurchase(payload);

        break;

      case 'listPurchases':

        result = listPurchases(payload.password);

        break;

      case 'updateStatus':

        result = updateStatus(payload);

        break;

      case 'ventaPresencialCompleta':

        result = ventaPresencialCompleta(payload);

        break;

      case 'listProductos':

        result = listProductos(payload.password);

        break;

      case 'guardarProducto':

        result = guardarProducto(payload);

        break;

      case 'eliminarProducto':

        result = eliminarProducto(payload);

        break;

      case 'listBebestiblesVentas':

        result = listBebestiblesVentas(payload.password);

        break;

      case 'deletePurchase':

        result = deletePurchase(payload);

        break;

      case 'resetAll':

        result = resetAll(payload);

        break;

      case 'getAvailability':

        result = getAvailability();

        break;

      case 'getModo':

        result = getModo();

        break;

      case 'setModo':

        result = setModo(payload);

        break;

      default:

        throw new Error('Acción no reconocida: ' + action);

    }

    return jsonOut({ ok: true, data: result });

  } catch (err) {

    return jsonOut({ ok: false, error: err.message });

  }

}



function doGet(e) {

  return jsonOut({ ok: true, msg: 'BINGO ANDINO 2026 backend activo' });

}



function jsonOut(obj) {

  return ContentService.createTextOutput(JSON.stringify(obj))

    .setMimeType(ContentService.MimeType.JSON);

}



function getSheet() {

  const ss = SpreadsheetApp.openById(SHEET_ID);

  let sheet = ss.getSheetByName(SHEET_NAME);

  if (!sheet) {

    sheet = ss.insertSheet(SHEET_NAME);

    sheet.appendRow([

      'ID', 'Fecha', 'Comprador', 'Alumno', 'Curso', 'WhatsApp',

      'Cantidad', 'CartonDesde', 'CartonHasta', 'Monto', 'Estado', 'FechaAprobacion',

      'Email', 'Modo', 'Sets'

    ]);

    sheet.setFrozenRows(1);

  }

  return sheet;

}



// Siguiente número de ID: el más alto que existe + 1 (evita IDs repetidos si se borran filas)

function nextSeq(sheet) {

  const last = sheet.getLastRow();

  let max = 0;

  if (last > 1) {

    const ids = sheet.getRange(2, 1, last - 1, 1).getValues();

    ids.forEach(function (r) {

      const n = parseInt(String(r[0]).replace(/\D/g, ''), 10);

      if (!isNaN(n) && n > max) max = n;

    });

  }

  return max + 1;

}



/* ============ MODO DE VENTA (preventa / evento) ============ */

function getModo() {

  const modo = PropertiesService.getScriptProperties().getProperty('MODO_VENTA') || 'preventa';

  return { modo: modo };

}

function setModo(p) {

  checkAdmin(p.password);

  if (['preventa', 'evento'].indexOf(p.modo) === -1) throw new Error('Modo inválido');

  PropertiesService.getScriptProperties().setProperty('MODO_VENTA', p.modo);

  return { ok: true, modo: p.modo };

}



// Última compra de una persona. Solo devuelve lo mínimo necesario (sin nombres ni montos).

function checkStatus(whatsapp) {

  if (!/^\d{9}$/.test(String(whatsapp))) throw new Error('WhatsApp inválido');

  const data = getSheet().getDataRange().getValues();

  let latest = null;

  for (let i = 1; i < data.length; i++) {

    if (String(data[i][5]) === String(whatsapp)) {

      latest = {

        id: data[i][0],

        cantidad: data[i][6], desde: data[i][7], hasta: data[i][8],

        estado: data[i][10]

      };

    }

  }

  if (!latest) throw new Error('No encontramos compras con ese número de WhatsApp');

  return latest;

}



function nextAvailableCard() {

  const data = getSheet().getDataRange().getValues();

  let max = 0;

  for (let i = 1; i < data.length; i++) {

    if (data[i][10] !== 'rechazada' && data[i][8] > max) max = data[i][8];

  }

  return max + 1;

}



function getAvailability() {

  return { disponibles: TOTAL_CARTONES - (nextAvailableCard() - 1), total: TOTAL_CARTONES };

}



function submitPurchase(p) {

  const lock = LockService.getScriptLock();

  lock.waitLock(30000);

  try {

    if (!/^\d{9}$/.test(String(p.whatsapp))) {

      throw new Error('El WhatsApp debe tener 9 dígitos (sin el +56)');

    }

    if (!p.nombreComprador || !p.nombreAlumno || !p.curso) {

      throw new Error('Faltan datos del formulario');

    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(p.email || ''))) {

      throw new Error('Ingresa un email válido');

    }

    const sets = parseInt(p.sets, 10);

    if (!sets || sets < 1) throw new Error('Cantidad de sets inválida');

    if (sets > MAX_SETS_POR_COMPRA) {

      throw new Error('El máximo por compra online es de ' + MAX_SETS_POR_COMPRA + ' sets. Si necesitas más, contáctate con el Cepama.');

    }



    const nombreComprador = String(p.nombreComprador).trim().slice(0, 80);

    const nombreAlumno = String(p.nombreAlumno).trim().slice(0, 80);

    const curso = String(p.curso).trim().slice(0, 40);

    const email = String(p.email).trim().slice(0, 120);



    const sheet = getSheet();



    // Límite de compras pendientes por WhatsApp (evita reservas falsas en masa)

    const all = sheet.getDataRange().getValues();

    let pendientesWsp = 0;

    for (let i = 1; i < all.length; i++) {

      if (String(all[i][5]) === String(p.whatsapp) && all[i][10] === 'pendiente') pendientesWsp++;

    }

    if (pendientesWsp >= MAX_PENDIENTES_POR_WSP) {

      throw new Error('Ya tienes ' + pendientesWsp + ' compras pendientes de validación con este WhatsApp. Espera la confirmación del Cepama.');

    }



    const modo = getModo().modo;

    const precio = calcularPrecio(modo, sets);

    const cantidad = precio.cartones;

    const monto = precio.monto;



    const desde = nextAvailableCard();

    const hasta = desde + cantidad - 1;

    if (hasta > TOTAL_CARTONES) {

      const restantes = Math.max(0, TOTAL_CARTONES - desde + 1);

      throw new Error('Solo quedan ' + restantes + ' cartones disponibles');

    }



    const id = 'C-' + padGAS(nextSeq(sheet));



    sheet.appendRow([

      id, new Date(), nombreComprador, nombreAlumno, curso, String(p.whatsapp),

      cantidad, desde, hasta, monto, 'pendiente', '', email, modo, sets

    ]);



    const row = {

      id: id, comprador: nombreComprador, alumno: nombreAlumno, curso: curso,

      whatsapp: p.whatsapp, email: email, cantidad: cantidad, desde: desde, hasta: hasta, monto: monto

    };

    try {

      sendPendingNotificationEmail(row);

    } catch (mailErr) {

      // no bloquea la compra si falla el aviso interno

    }



    return { id: id, desde: desde, hasta: hasta, monto: monto, cantidad: cantidad, modo: modo, sets: sets };

  } finally {

    lock.releaseLock();

  }

}



// Venta presencial combinada: cartones y/o bebestibles en una sola transacción.

// Se cobra en efectivo/directo en el momento, así que queda "aceptada" de inmediato.

function ventaPresencialCompleta(p) {

  checkAdmin(p.password);

  const lock = LockService.getScriptLock();

  lock.waitLock(30000);

  try {

    const nombre = p.nombreComprador ? String(p.nombreComprador).trim().slice(0, 80) : 'Venta presencial';

    const now = new Date();

    let cartones = null;



    const cantidadCartones = parseInt(p.cantidadCartones, 10) || 0;

    if (cantidadCartones > 0) {

      const montoCartones = parseInt(p.montoCartones, 10);

      if (isNaN(montoCartones) || montoCartones < 0) throw new Error('Monto de cartones inválido');

      const desde = nextAvailableCard();

      const hasta = desde + cantidadCartones - 1;

      if (hasta > TOTAL_CARTONES) {

        const restantes = Math.max(0, TOTAL_CARTONES - desde + 1);

        throw new Error('Solo quedan ' + restantes + ' cartones disponibles');

      }

      const sheet = getSheet();

      const id = 'C-' + padGAS(nextSeq(sheet));

      sheet.appendRow([id, now, nombre, '', '', '', cantidadCartones, desde, hasta, montoCartones, 'aceptada', now, '', 'presencial', '']);

      cartones = { id: id, desde: desde, hasta: hasta, cantidad: cantidadCartones, monto: montoCartones };

    }



    let bebestibles = null;

    const items = Array.isArray(p.bebestiblesItems) ? p.bebestiblesItems : [];

    let montoBebestibles = 0;

    const itemsTxt = [];

    items.forEach(function (it) {

      const cant = parseInt(it.cantidad, 10) || 0;

      const precio = parseInt(it.precioUnit, 10) || 0;

      if (cant > 0) {

        montoBebestibles += cant * precio;

        itemsTxt.push(it.nombre + ' x' + cant);

      }

    });

    if (montoBebestibles > 0) {

      const bSheet = getBebestiblesSheet();

      const bId = 'B-' + padGAS(nextSeq(bSheet));

      bSheet.appendRow([bId, now, nombre, itemsTxt.join(', '), montoBebestibles, cartones ? cartones.id : '']);

      bebestibles = { id: bId, items: itemsTxt.join(', '), monto: montoBebestibles };

    }



    if (!cartones && !bebestibles) {

      throw new Error('Agrega al menos cartones o bebestibles para registrar la venta.');

    }



    return {

      comprador: nombre,

      fecha: now,

      cartones: cartones,

      bebestibles: bebestibles,

      montoTotal: (cartones ? cartones.monto : 0) + (bebestibles ? bebestibles.monto : 0)

    };

  } finally {

    lock.releaseLock();

  }

}



/* ============ CATÁLOGO DE BEBESTIBLES ============ */

function getProductosSheet() {

  const ss = SpreadsheetApp.openById(SHEET_ID);

  let sheet = ss.getSheetByName('Productos');

  if (!sheet) {

    sheet = ss.insertSheet('Productos');

    sheet.appendRow(['ID', 'Nombre', 'Precio']);

    sheet.setFrozenRows(1);

    // catálogo inicial sugerido; se puede editar o borrar desde el panel

    const iniciales = [

      ['Latas Bebidas', 2000], ['Lipton Lata', 1500], ['Botella Bilz - Pap', 2000],

      ['Jugo Corea', 2000], ['Lata Corea', 2000], ['Café', 2000], ['Té', 1300]

    ];

    iniciales.forEach(function (prod) {

      sheet.appendRow(['P-' + Utilities.getUuid().slice(0, 6).toUpperCase(), prod[0], prod[1]]);

    });

  }

  return sheet;

}



function listProductos(password) {

  checkAdmin(password);

  const data = getProductosSheet().getDataRange().getValues();

  const rows = [];

  for (let i = 1; i < data.length; i++) {

    rows.push({ id: data[i][0], nombre: data[i][1], precio: data[i][2] });

  }

  return { rows: rows };

}



function guardarProducto(p) {

  checkAdmin(p.password);

  const nombre = String(p.nombre || '').trim().slice(0, 80);

  const precio = parseInt(p.precio, 10);

  if (!nombre) throw new Error('Falta el nombre del producto');

  if (isNaN(precio) || precio < 0) throw new Error('Precio inválido');

  const sheet = getProductosSheet();

  const data = sheet.getDataRange().getValues();

  if (p.id) {

    for (let i = 1; i < data.length; i++) {

      if (data[i][0] === p.id) {

        sheet.getRange(i + 1, 2).setValue(nombre);

        sheet.getRange(i + 1, 3).setValue(precio);

        return { ok: true, id: p.id };

      }

    }

  }

  const id = 'P-' + Utilities.getUuid().slice(0, 6).toUpperCase();

  sheet.appendRow([id, nombre, precio]);

  return { ok: true, id: id };

}



function eliminarProducto(p) {

  checkAdmin(p.password);

  const sheet = getProductosSheet();

  const data = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {

    if (data[i][0] === p.id) {

      sheet.deleteRow(i + 1);

      return { ok: true };

    }

  }

  throw new Error('Producto no encontrado');

}



/* ============ VENTAS DE BEBESTIBLES (registro) ============ */

function getBebestiblesSheet() {

  const ss = SpreadsheetApp.openById(SHEET_ID);

  let sheet = ss.getSheetByName('VentasBebestibles');

  if (!sheet) {

    sheet = ss.insertSheet('VentasBebestibles');

    sheet.appendRow(['ID', 'Fecha', 'Comprador', 'Items', 'MontoTotal', 'VentaCartonesRef']);

    sheet.setFrozenRows(1);

  }

  return sheet;

}



function listBebestiblesVentas(password) {

  checkAdmin(password);

  const data = getBebestiblesSheet().getDataRange().getValues();

  const rows = [];

  for (let i = 1; i < data.length; i++) {

    rows.push({

      id: data[i][0], fecha: data[i][1], comprador: data[i][2],

      items: data[i][3], monto: data[i][4], ventaCartonesRef: data[i][5]

    });

  }

  return { rows: rows };

}



function listPurchases(password) {

  checkAdmin(password);

  const data = getSheet().getDataRange().getValues();

  const rows = [];

  for (let i = 1; i < data.length; i++) {

    rows.push({

      id: data[i][0], fecha: data[i][1], comprador: data[i][2], alumno: data[i][3],

      curso: data[i][4], whatsapp: data[i][5], cantidad: data[i][6], desde: data[i][7],

      hasta: data[i][8], monto: data[i][9], estado: data[i][10], fechaAprobacion: data[i][11],

      email: data[i][12] || '', modo: data[i][13] || '', sets: data[i][14] || ''

    });

  }

  return { rows: rows, disponibles: TOTAL_CARTONES - (nextAvailableCard() - 1), total: TOTAL_CARTONES };

}



function deletePurchase(p) {

  checkAdmin(p.password);

  const sheet = getSheet();

  const data = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {

    if (data[i][0] === p.id) {

      sheet.deleteRow(i + 1);

      return { ok: true };

    }

  }

  throw new Error('ID no encontrado');

}



function resetAll(p) {

  checkAdmin(p.password);

  if (p.confirmacion !== 'BORRAR TODO') throw new Error('Confirmación inválida');

  const sheet = getSheet();

  const lastRow = sheet.getLastRow();

  if (lastRow > 1) {

    sheet.deleteRows(2, lastRow - 1);

  }

  return { ok: true };

}



function updateStatus(p) {

  checkAdmin(p.password);

  if (['pendiente', 'aceptada', 'rechazada'].indexOf(p.estado) === -1) {

    throw new Error('Estado inválido');

  }

  const sheet = getSheet();

  const data = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {

    if (data[i][0] === p.id) {

      sheet.getRange(i + 1, 11).setValue(p.estado);

      let emailWarning = '';

      if (p.estado === 'aceptada') {

        sheet.getRange(i + 1, 12).setValue(new Date());

        const row = {

          id: data[i][0], comprador: data[i][2], alumno: data[i][3], curso: data[i][4],

          whatsapp: data[i][5], cantidad: data[i][6], desde: data[i][7], hasta: data[i][8],

          monto: data[i][9], email: data[i][12] || ''

        };

        if (row.email) {

          try {

            sendAcceptanceEmail(row);

          } catch (mailErr) {

            emailWarning = 'Estado actualizado, pero el email falló: ' + mailErr.message;

          }

        } else {

          emailWarning = 'Estado actualizado, pero esta compra no tiene email registrado.';

        }

      }

      return { ok: true, emailWarning: emailWarning };

    }

  }

  throw new Error('ID no encontrado');

}



/* ============ EMAIL: AVISO INTERNO DE COMPRA PENDIENTE ============ */

function sendPendingNotificationEmail(row) {

  const rangoTxt = row.desde === row.hasta

    ? ('BA-' + padGAS(row.desde))

    : ('BA-' + padGAS(row.desde) + ' al BA-' + padGAS(row.hasta));

  const subject = '📥 Nueva compra pendiente - BINGO ANDINO 2026 (' + row.id + ')';

  const body =

    'Nueva compra registrada, pendiente de validar:\n\n' +

    'N° de compra: ' + row.id + '\n' +

    'Comprador: ' + row.comprador + '\n' +

    'Alumno/a: ' + row.alumno + ' (' + row.curso + ')\n' +

    'WhatsApp: +56' + row.whatsapp + '\n' +

    'Email: ' + row.email + '\n' +

    'Cartones asignados: ' + rangoTxt + '\n' +

    'Monto a verificar: $' + Number(row.monto).toLocaleString('es-CL') + '\n\n' +

    'Revisa el comprobante y aprueba o rechaza desde el panel de administración.';

  MailApp.sendEmail(CEPAMA_NOTIFY_EMAIL, subject, body);

}



/* ============ EMAIL DE ACEPTACIÓN CON CARTONES ============ */

function sendAcceptanceEmail(row) {

  const subject = '🎉 Tu compra de BINGO ANDINO 2026 fue aprobada (' + row.id + ')';

  const html = acceptedEmailHtml(row);

  MailApp.sendEmail({

    to: row.email,

    subject: subject,

    htmlBody: html,

    name: MAIL_FROM_NAME

  });

}



function acceptedEmailHtml(row) {

  const rangoTxt = row.desde === row.hasta

    ? ('BA-' + padGAS(row.desde))

    : ('BA-' + padGAS(row.desde) + ' al BA-' + padGAS(row.hasta));

  return (

    '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">' +

      '<div style="background:#15264D;color:#fff;padding:20px;text-align:center;border-radius:8px 8px 0 0;">' +

        '<h1 style="margin:0;font-size:24px;">BINGO ANDINO 2026</h1>' +

        '<p style="margin:4px 0 0;">Colegio Andino Montessori</p>' +

      '</div>' +

      '<div style="padding:20px;background:#F6F1E4;">' +

        '<p>Hola <b>' + escapeHtmlGAS(row.comprador) + '</b>,</p>' +

        '<p>Tu compra para <b>' + escapeHtmlGAS(row.alumno) + '</b> (' + escapeHtmlGAS(row.curso) + ') fue <b style="color:#3F7D4F;">APROBADA ✅</b>.</p>' +

        '<p>N° de compra: <b>' + escapeHtmlGAS(row.id) + '</b> (guárdalo para retirar tus cartones)</p>' +

        '<p>Monto: <b>$' + Number(row.monto).toLocaleString('es-CL') + '</b> — Cantidad: <b>' + row.cantidad + ' cartón(es)</b></p>' +

        '<p>Tus números de cartón: <b>' + rangoTxt + '</b></p>' +

        '<p>Tus cartones se entregan de forma <b>física</b>. Presenta tu N° de compra (' + escapeHtmlGAS(row.id) + ') al retirarlos.</p>' +

      '</div>' +

    '</div>'

  );

}



function escapeHtmlGAS(s) {

  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {

    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];

  });

}



function padGAS(n) { return String(n).padStart(4, '0'); }